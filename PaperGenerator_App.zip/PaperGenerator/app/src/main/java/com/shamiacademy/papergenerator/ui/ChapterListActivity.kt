package com.shamiacademy.papergenerator.ui

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.shamiacademy.papergenerator.R
import com.shamiacademy.papergenerator.ads.RewardedAdManager
import com.shamiacademy.papergenerator.network.DataRepository
import com.shamiacademy.papergenerator.util.UnlockManager
import com.shamiacademy.papergenerator.util.buildRow

class ChapterListActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list)

        val classId = intent.getStringExtra("classId") ?: return
        val subjectId = intent.getStringExtra("subjectId") ?: return
        val subjectName = intent.getStringExtra("subjectName") ?: ""
        val subjectNameUr = intent.getStringExtra("subjectNameUr") ?: ""

        val title = findViewById<TextView>(R.id.titleText)
        val container = findViewById<LinearLayout>(R.id.listContainer)
        val progress = findViewById<android.widget.ProgressBar>(R.id.progressBar)
        title.text = "$subjectName ($subjectNameUr) - ابواب"

        RewardedAdManager.preload(this)

        DataRepository.getChapters(classId, subjectId) { chapters ->
            runOnUiThread {
                progress.visibility = android.view.View.GONE
                val list = chapters ?: emptyList()
                if (list.isEmpty()) {
                    container.addView(TextView(this).apply {
                        text = "ابھی اس مضمون کے ابواب شامل نہیں کیے گئے۔"
                        setPadding(24, 24, 24, 24)
                    })
                    return@runOnUiThread
                }
                list.forEachIndexed { index, chapter ->
                    val unlocked = UnlockManager.isChapterUnlocked(this, classId, subjectId, index)
                    val label = "${chapter.number}. ${chapter.name}"
                    container.addView(buildRow(this, label, chapter.name_ur, locked = !unlocked) {
                        if (unlocked) {
                            val intent = Intent(this, QuestionSelectionActivity::class.java)
                            intent.putExtra("classId", classId)
                            intent.putExtra("subjectId", subjectId)
                            intent.putExtra("subjectName", subjectName)
                            intent.putExtra("subjectNameUr", subjectNameUr)
                            intent.putExtra("chapterId", chapter.id)
                            intent.putExtra("chapterName", chapter.name)
                            intent.putExtra("chapterNameUr", chapter.name_ur)
                            startActivity(intent)
                        } else {
                            RewardedAdManager.show(this,
                                onUnlocked = {
                                    UnlockManager.unlockChapter(this, classId, subjectId, index)
                                    Toast.makeText(this, "باب اَن لاک ہو گیا!", Toast.LENGTH_SHORT).show()
                                    recreate()
                                },
                                onUnavailable = {
                                    Toast.makeText(this, "اشتہار ابھی دستیاب نہیں، تھوڑی دیر بعد کوشش کریں۔", Toast.LENGTH_SHORT).show()
                                })
                        }
                    })
                }
            }
        }
    }
}
